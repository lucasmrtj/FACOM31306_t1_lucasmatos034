public class SemestreInvalidoException extends RuntimeException {
    public SemestreInvalidoException(String message) {
        super(message);
    }
}
