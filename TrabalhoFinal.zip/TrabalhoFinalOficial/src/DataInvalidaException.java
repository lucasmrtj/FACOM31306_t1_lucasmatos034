public class DataInvalidaException extends RuntimeException {
    public DataInvalidaException(String msg) {
        super(msg);
    }
}