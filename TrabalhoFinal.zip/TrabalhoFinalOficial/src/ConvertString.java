 public interface ConvertString {
    String toString();
 }