public class CRAInvalidoException extends RuntimeException {
    public CRAInvalidoException(String msg) {
        super(msg);
    }
}